


$(document).ready(function() {
    var max_fields      = 100; //maximum input boxes 

    var wrapper         = $(".fieldList"); //Fields wrapper
    var add_button      = $(".add_field_button"); //Add button ID
	var done_button      = $(".done_button"); //Add button ID

    var x = 1; //initlal text box count
	 $('#submit').hide();

    $(add_button).click(function(e){ //on add input button click
        e.preventDefault();				
        if(x < max_fields){ //max input box allowed
			$(wrapper).append("<label for='menu["+x+"][dish_cat]'>:קטגוריה</label>");
            $(wrapper).append("<input type='text' name='menu["+x+"][dish_cat]' placeholder='קטגוריה'><br>"); //add input box	
				$(wrapper).append("<label for='menu["+x+"][dish_name]'>:מנה</label>");
            $(wrapper).append("<input type='text' name='menu["+x+"][dish_name]' placeholder='שם המנה'><br>"); //add input box	
		$(wrapper).append("<label for='menu["+x+"][dish_description]'>:תיאור המנה</label>");
			$(wrapper).append("<input type='text' name='menu["+x+"][dish_description]'placeholder='תיאור המנה'><br>"); //add input box
					$(wrapper).append("<label for='menu["+x+"][dish_price]'>:מחיר המנה</label>");				
			$(wrapper).append("<input type='text' name='menu["+x+"][dish_price]'placeholder='מחיר המנה'><br>"); //add input box	
			$(wrapper).append("<br>");
			x++; //text box increment
        }
    });
	$(done_button).click(function(e){ //on add input button click
		$('#submit').show();	

    });
	
(function($){
    $.fn.serializeObject = function(){

        var self = this,
            json = {},
            push_counters = {},
            patterns = {
                "validate": /^[a-zA-Z][a-zA-Z0-9_]*(?:\[(?:\d*|[a-zA-Z0-9_]+)\])*$/,
                "key":      /[a-zA-Z0-9_]+|(?=\[\])/g,
                "push":     /^$/,
                "fixed":    /^\d+$/,
                "named":    /^[a-zA-Z0-9_]+$/
            };


        this.build = function(base, key, value){
            base[key] = value;
            return base;
        };

        this.push_counter = function(key){
            if(push_counters[key] === undefined){
                push_counters[key] = 0;
            }
            return push_counters[key]++;
        };

        $.each($(this).serializeArray(), function(){

            // skip invalid keys
            if(!patterns.validate.test(this.name)){
                return;
            }

            var k,
                keys = this.name.match(patterns.key),
                merge = this.value,
                reverse_key = this.name;

            while((k = keys.pop()) !== undefined){

                // adjust reverse_key
                reverse_key = reverse_key.replace(new RegExp("\\[" + k + "\\]$"), '');

                // push
                if(k.match(patterns.push)){
                    merge = self.build([], self.push_counter(reverse_key), merge);
                }

                // fixed
                else if(k.match(patterns.fixed)){
                    merge = self.build([], k, merge);
                }

                // named
                else if(k.match(patterns.named)){
                    merge = self.build({}, k, merge);
                }
            }

            json = $.extend(true, json, merge);
        });

        return json;
    };
})(jQuery);

	$(function(){
		$('#set-menu').submit(function(){
			//e.preventDefault();
			$.post($(this).attr('action'))
		//	var temp=$(this).serializeObject();
			//alert(temp);
			//	var tempCat=temp.menu[0]['dish_cat'];
				//alert(tempCat);
			//first table for the first category
			
			var tbl=$("<table/>").attr("id","mytable");
			$(".modal-body").append(tbl);
			var str=" "+tempCat+"<br>";
			$(".modal-body").append(str);
			var td="<tr>";
			var td1="<td>שם המנה</td>";
			var td2="<td>תיאור המנה</td>";
			var td3="<td>מחיר המנה</td></tr>";
			$(".modal-body").append(td+td1+td2+td3);	
				
			var tr="<tr>";
			var td1="<td>"+temp.menu[0]['dish_name']+"</td>";
			var td2="<td>"+temp.menu[0]["dish_description"]+"</td>";
			var td3="<td>"+temp.menu[0]["dish_price"]+"</td></tr>";

			$(".modal-body").append(tr+td1+td2+td3); 
			
			/*
			// sort all the dishes by category into tables
			for(var i=1;i<temp.menu.length;i++)
			{
				if(tempCat.localeCompare(temp.menu[i]['dish_cat'])==0)//same category
				{
					var tr="<tr>";
					var td1="<td>"+temp.menu[i]['dish_name']+"</td>";
					var td2="<td>"+temp.menu[i]["dish_description"]+"</td>";
					var td3="<td>"+temp.menu[i]["dish_price"]+"</td></tr>";
					$(".modal-body").append(tr+td1+td2+td3); 
			
				}
				else// case new cat
				{
					var tempCat=temp.menu[i]['dish_cat'];
					var str=" "+tempCat+"<br>";
					$(".modal-body").append(str);
					var td="<tr>";
					var td1="<td>שם המנה</td>";
					var td2="<td>תיאור המנה</td>";
					var td3="<td>מחיר המנה</td></tr>";
					$(".modal-body").append(td+td1+td2+td3);
					var tr="<tr>";
					var td1="<td>"+temp.menu[i]['dish_name']+"</td>";
					var td2="<td>"+temp.menu[i]["dish_description"]+"</td>";
					var td3="<td>"+temp.menu[i]["dish_price"]+"</td></tr>";
					$(".modal-body").append(tr+td1+td2+td3); 
				}	
			}					
			$('#myModal').modal('show');
				$('#confirm-save-button').on('click', function() {
					//alert('Saved!!');
						$('#myModal').modal('hide');
				
				});	
			//return false;
			*/
		});
	});
	
	
    $(wrapper).on("click",".remove_field", function(e){ //user click on remove text
        e.preventDefault(); $(this).parent('div').remove(); x--;
    })
});