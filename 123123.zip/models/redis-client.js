var client;
  

module.exports = {
 setClient : function(inClient) { client = inClient; };
}

eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6IjAiLCJpYXQiOjE1MjU1MjUwODUsImV4cCI6MTUyNTUyNjUyNX0.9bMIk3xkk4kCf3ouXOIo5dumQD3rBXpQgjut8pZwFQc