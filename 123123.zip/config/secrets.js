module.exports = {

  apiKey: 'AIzaSyBwMyNbVpmbIbHeQDmXwIDoDfu6i65IRVw',
  secretAccessKey: 'Xi4xCO/vCYwkBJDsh6b/j4qAllbKpS6OlwJBegoy',
   accessKeyId: 'AKIAITDMQNPWWZS2QTQA',
  cookieSecret : 'djaskldjksj',
  passwordForRedis:'KYGcSenPYc3a4xDBLV3ECCDM5aBBU73w'
};
